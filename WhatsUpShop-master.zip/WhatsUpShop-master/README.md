# WhatsUpShop
Nice and simplified online store CMS based on PHP and MySQL

PLEASE NOTE: It is improved version of WhatsUpOnlineStore, the previous version of this program in this link: https://github.com/habibieamrullah/WhatsUpOnlineStore, which to get started, first you need to configure your database credential by editing dbcon.php. In previous version, database credential configuration was inside config.php, but here I've managed to create separated dbcon.php file for it.

## About WhatsUpShop
 
This PHP software is a lightweight and simple CMS system that allows you to post products with pictures, description, pricing, quantity and options.

It has easy to use Shopping cart, add to cart button and finally a WhatsApp checkout system to send the seller a notification about what product is being ordered with all the details needed.

You can customize this online shop by visiting its settings page on its Admin panel, change theme color, etc.

Watch this video to learn how to setup this online shop:

https://youtu.be/NRy8SnLLpe4

If you like this work, visit my YouTube channel, like and subscribe. If you have money to appreciate this work, please donate to: https://paypal.me/habibieamrullah
